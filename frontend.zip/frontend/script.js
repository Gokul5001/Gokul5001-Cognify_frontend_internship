// Change Background Color on Button Click
document.getElementById('changeColorButton').addEventListener('click', function() {
    const data = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += data[Math.floor(Math.random() * 16)];
    }
    console.log(color);
    document.body.style.backgroundColor = color;
});

// Fetch Data from API and Update the DOM when Fetch Data Button is Clicked
document.getElementById('fetchDataButton').addEventListener('click', function() {
    fetch('https://jsonplaceholder.typicode.com/users')
        .then(response => response.json())
        .then(data => {
            const dataList = document.getElementById('data-list');
            dataList.innerHTML = ''; // Clear existing data
            data.slice(0, 10).forEach(user => {
                const listItem = document.createElement('li');
                listItem.className = "list-group-item"; // Add Bootstrap class for styling
                listItem.textContent = `Name: ${user.name}`;
                dataList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
});
