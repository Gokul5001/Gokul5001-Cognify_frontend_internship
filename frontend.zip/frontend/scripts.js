document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('loginForm');
    const usernameInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    const feedback = document.getElementById('feedback');

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        // Reset previous errors
        usernameError.style.display = 'none';
        passwordError.style.display = 'none';
        feedback.style.display = 'none';
        feedback.classList.remove('alert', 'alert-success', 'alert-danger');
        const username = usernameInput.value;
        const password = passwordInput.value;
        let isValid = true;

        if (username === '') {
            usernameError.textContent = 'Username is required.';
            usernameError.style.display = 'block';
            isValid = false;
        }

        if (password === '') {
            passwordError.textContent = 'Password is required.';
            passwordError.style.display = 'block';
            isValid = false;
        }

        if (isValid) {
            // Simulate an API call
            setTimeout(() => {
                if (username === 'test@example.com' && password === 'password') {
                    // Display success message
                    feedback.textContent = 'Login successful! Redirecting to the home page...';
                    feedback.classList.add('alert', 'alert-success');
                    feedback.style.display = 'block';
                    
                    // Delay the redirection
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 2000); // Delay in milliseconds (2 seconds)
                } else {
                    // Display error message
                    feedback.textContent = 'Invalid username or password.';
                    feedback.classList.add('alert', 'alert-danger');
                    feedback.style.display = 'block';
                }
            }, 1000); // Simulate server response delay
        }
    });
});
